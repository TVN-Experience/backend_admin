<?php
	header("location: dashboard");
	die();
?>